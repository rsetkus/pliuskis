#!/usr/bin/env sh
# End-to-end check of the app <-> device MQTT contract against a running staging stack.
# It plays the app: discovers basil and fern, asks basil for status, and waters it.
#
#   scripts/smoke-test.sh [HOST] [PORT]        (defaults: localhost 1883)
#
# Needs mosquitto_sub and mosquitto_pub (package mosquitto-clients).
set -eu

HOST=${1:-localhost}
PORT=${2:-1883}
APP="smoke-test-$$"
REPLY_TOPIC="application/$APP/basil/status"
# The exact shape the app's strict decoder accepts: three keys, timestamp as an object.
STATUS_SHAPE='^\{"humidity":[0-9.]+,"waterLevel":[0-9.]+,"timestamp":\{"epochSeconds":[0-9]+(,"nanosecondsOfSecond":[0-9]+)?\}\}$'

WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT

fail() {
    echo "FAIL: $*" >&2
    exit 1
}

pass() {
    echo "ok    $*"
}

sub() {
    mosquitto_sub -h "$HOST" -p "$PORT" "$@"
}

pub() {
    mosquitto_pub -h "$HOST" -p "$PORT" -q 1 "$@"
}

humidity_of() {
    sed -n 's/^{"humidity":\([0-9.]*\),.*/\1/p'
}

# 1. Discovery: retained info and availability, as the app's device list sees them.
for device in basil fern; do
    info=$(sub -t "devices/$device/info" -C 1 -W 5 -F '%r %p') || fail "$device: no info on devices/$device/info"
    case "$info" in
        "1 {\"name\":"*"\"deviceId\":\"$device\",\"type\":\"plant\"}") pass "$device: retained info ${info#1 }" ;;
        *) fail "$device: expected retained info, got '$info'" ;;
    esac

    availability=$(sub -t "devices/$device/availability" -C 1 -W 5 -F '%r %p') ||
        fail "$device: nothing on devices/$device/availability"
    [ "$availability" = "1 online" ] || fail "$device: expected retained 'online', got '$availability'"
    pass "$device: retained availability online"
done

# 2. Status: request on devices/basil/status, reply on application/{applicationId}/basil/status.
sub -t "$REPLY_TOPIC" -C 1 -W 10 > "$WORK/status" &
listener=$!
sleep 1
pub -t devices/basil/status -m "{\"applicationId\":\"$APP\"}"
wait "$listener" || fail "basil: no status reply on $REPLY_TOPIC"
status=$(cat "$WORK/status")
echo "$status" | grep -Eq "$STATUS_SHAPE" || fail "basil: status doesn't match the app's SystemState: $status"
pass "basil: status reply $status"

# 3. Command: watering raises humidity. Periodic updates may arrive in between, so look at a few messages.
before=$(echo "$status" | humidity_of)
sub -t "$REPLY_TOPIC" -C 3 -W 12 > "$WORK/after-water" &
listener=$!
sleep 1
pub -t devices/basil/command -m '{"command":"water"}'
wait "$listener" || true
watered=$(humidity_of < "$WORK/after-water" | awk -v before="$before" '$1 > before { print; exit }')
[ -n "$watered" ] || fail "basil: humidity didn't rise above $before after watering: $(cat "$WORK/after-water")"
pass "basil: watered, humidity $before -> $watered"

echo "Smoke test passed against $HOST:$PORT"
