package lt.setkus.pliuskis.mockdevice.mqtt

import com.hivemq.client.mqtt.MqttClient
import com.hivemq.client.mqtt.MqttGlobalPublishFilter
import com.hivemq.client.mqtt.datatypes.MqttQos
import com.hivemq.client.mqtt.lifecycle.MqttDisconnectSource
import com.hivemq.client.mqtt.mqtt3.Mqtt3AsyncClient
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.future.await
import kotlinx.coroutines.withTimeoutOrNull
import lt.setkus.pliuskis.mockdevice.Logger
import lt.setkus.pliuskis.mockdevice.config.BrokerConfig
import lt.setkus.pliuskis.mockdevice.contract.OFFLINE
import lt.setkus.pliuskis.mockdevice.contract.Topics
import java.util.concurrent.TimeUnit
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

/** Same backoff as the firmware's `connect_with_backoff`: 1 s, doubling up to 30 s. */
private const val RECONNECT_INITIAL_DELAY_SECONDS = 1L
private const val RECONNECT_MAX_DELAY_SECONDS = 30L
private val OPERATION_TIMEOUT = 10.seconds

/** Kept short so the whole shutdown fits in `docker compose stop`'s 10 s grace period. */
private val SHUTDOWN_STEP_TIMEOUT = 2.seconds

/**
 * MQTT 3.1.1 connection with the device id as client id and a retained `offline` Last Will, the same
 * session setup as the Pico firmware.
 */
class HiveMqttDeviceConnection(
    private val broker: BrokerConfig,
    deviceId: String,
    private val log: Logger
) : DeviceConnection {

    private val eventChannel = Channel<ConnectionEvent>(Channel.UNLIMITED)
    override val events: ReceiveChannel<ConnectionEvent> = eventChannel

    private val availabilityTopic = Topics.availability(deviceId)

    // Listeners and callbacks run on netty threads: they only hand events over, never block.
    private val client: Mqtt3AsyncClient = MqttClient.builder()
        .useMqttVersion3()
        .identifier(deviceId)
        .serverHost(broker.host)
        .serverPort(broker.port)
        .automaticReconnect()
        .initialDelay(RECONNECT_INITIAL_DELAY_SECONDS, TimeUnit.SECONDS)
        .maxDelay(RECONNECT_MAX_DELAY_SECONDS, TimeUnit.SECONDS)
        .applyAutomaticReconnect()
        .willPublish()
        .topic(availabilityTopic)
        .payload(OFFLINE.toByteArray(Charsets.UTF_8))
        .qos(MqttQos.AT_LEAST_ONCE)
        .retain(true)
        .applyWillPublish()
        .addConnectedListener { eventChannel.trySend(ConnectionEvent.Connected) }
        .addDisconnectedListener { context ->
            // A user-initiated disconnect is the clean shutdown, which goOffline() already logs.
            if (context.source != MqttDisconnectSource.USER) {
                log.warn(
                    "Disconnected from ${broker.host}:${broker.port}: ${context.cause.message}; " +
                        "retrying (attempt ${context.reconnector.attempts + 1})"
                )
            }
        }
        .buildAsync()

    init {
        // One global callback for every subscription, so a resubscribe can never register a duplicate handler.
        client.publishes(MqttGlobalPublishFilter.SUBSCRIBED) { publish ->
            eventChannel.trySend(
                ConnectionEvent.Message(publish.topic.toString(), String(publish.payloadAsBytes, Charsets.UTF_8))
            )
        }
    }

    override fun connect() {
        log.info("Connecting to ${broker.host}:${broker.port}")
        client.connectWith()
            .cleanSession(true)
            .keepAlive(broker.keepAliveSeconds)
            .send()
    }

    override suspend fun subscribe(topic: String): Boolean = attempt("Subscribe to $topic") {
        client.subscribeWith()
            .topicFilter(topic)
            .qos(MqttQos.AT_LEAST_ONCE)
            .send()
            .await()
    }

    override suspend fun publish(topic: String, payload: String, retain: Boolean): Boolean =
        attempt("Publish to $topic") {
            client.publishWith()
                .topic(topic)
                .payload(payload.toByteArray(Charsets.UTF_8))
                .qos(MqttQos.AT_LEAST_ONCE)
                .retain(retain)
                .send()
                .await()
        }

    override suspend fun goOffline() {
        if (client.state.isConnected) {
            attempt("Publish offline", SHUTDOWN_STEP_TIMEOUT) {
                client.publishWith()
                    .topic(availabilityTopic)
                    .payload(OFFLINE.toByteArray(Charsets.UTF_8))
                    .qos(MqttQos.AT_LEAST_ONCE)
                    .retain(true)
                    .send()
                    .await()
            }
            attempt("Disconnect", SHUTDOWN_STEP_TIMEOUT) { client.disconnect().await() }
            log.info("Published offline and disconnected")
        }
    }

    /** Runs a broker round trip; failures and timeouts are logged, never thrown into the device loop. */
    private suspend fun attempt(
        action: String,
        timeout: Duration = OPERATION_TIMEOUT,
        block: suspend () -> Unit
    ): Boolean {
        val result = runCatching { withTimeoutOrNull(timeout) { block() } }
            .onFailure { error -> if (error is CancellationException) throw error }
        val succeeded = result.getOrNull() != null
        if (!succeeded) {
            log.warn("$action failed: ${result.exceptionOrNull()?.message ?: "timed out after $timeout"}")
        }
        return succeeded
    }
}
