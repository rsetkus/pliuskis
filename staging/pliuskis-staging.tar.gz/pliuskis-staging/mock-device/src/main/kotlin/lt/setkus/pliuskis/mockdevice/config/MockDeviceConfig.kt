package lt.setkus.pliuskis.mockdevice.config

import lt.setkus.pliuskis.mockdevice.contract.isSafeId
import lt.setkus.pliuskis.mockdevice.plant.MAX_LEVEL
import lt.setkus.pliuskis.mockdevice.plant.MIN_LEVEL
import kotlin.time.Duration
import kotlin.time.Duration.Companion.minutes
import kotlin.time.Duration.Companion.seconds

private const val DEFAULT_HOST = "localhost"
private const val DEFAULT_PORT = 1883
private const val MAX_PORT = 65_535

/** Same keepalive as the firmware; the broker publishes the Last Will after 1.5 × this without traffic. */
private const val DEFAULT_KEEPALIVE_SECONDS = 60
private const val MAX_KEEPALIVE_SECONDS = 65_535
private const val DEFAULT_TYPE = "plant"
private const val DEFAULT_HUMIDITY = 8f
private const val DEFAULT_WATER_LEVEL = 10f
private const val DEFAULT_DRYING_PER_MINUTE = 0.5f

/** The firmware's `checkin` interval. */
private const val DEFAULT_STATUS_INTERVAL_SECONDS = 5

/** How long an app keeps getting status updates after its last request. */
private val SUBSCRIBER_TTL = 10.minutes

data class BrokerConfig(
    val host: String,
    val port: Int,
    val keepAliveSeconds: Int
)

data class DeviceConfig(
    val id: String,
    val name: String,
    val type: String
)

data class SimulationConfig(
    val initialHumidity: Float,
    val initialWaterLevel: Float,
    val dryingPerMinute: Float,
    val statusInterval: Duration,
    val subscriberTtl: Duration,
    val fault: Fault
)

/** Deliberate misbehaviour, to exercise the app's unhappy paths. */
enum class Fault(val key: String) {
    /** Behaves like a healthy device. */
    NONE("none"),

    /** Announces itself but never answers status requests: the control screen stays in Loading. */
    SILENT("silent"),

    /** Answers with a status the app can't decode: the control screen shows its Error state. */
    MALFORMED_STATUS("malformed-status");

    companion object {
        fun fromKey(key: String): Fault? = entries.find { it.key == key }
    }
}

data class MockDeviceConfig(
    val broker: BrokerConfig,
    val device: DeviceConfig,
    val simulation: SimulationConfig
) {
    companion object {
        /** Reads the configuration from environment variables; fails fast with a readable message. */
        fun fromEnv(env: Map<String, String>): MockDeviceConfig {
            val reader = EnvReader(env)
            val deviceId = reader.required("DEVICE_ID")
            require(isSafeId(deviceId)) { "DEVICE_ID '$deviceId' may only contain letters, digits, '_' and '-'" }
            return MockDeviceConfig(
                broker = BrokerConfig(
                    host = reader.string("MQTT_HOST", DEFAULT_HOST),
                    port = reader.int("MQTT_PORT", DEFAULT_PORT, 1..MAX_PORT),
                    keepAliveSeconds = reader.int(
                        "MQTT_KEEPALIVE_SECONDS",
                        DEFAULT_KEEPALIVE_SECONDS,
                        1..MAX_KEEPALIVE_SECONDS
                    )
                ),
                device = DeviceConfig(
                    id = deviceId,
                    name = reader.string("DEVICE_NAME", deviceId),
                    type = reader.string("DEVICE_TYPE", DEFAULT_TYPE)
                ),
                simulation = SimulationConfig(
                    initialHumidity = reader.level("HUMIDITY", DEFAULT_HUMIDITY),
                    initialWaterLevel = reader.level("WATER_LEVEL", DEFAULT_WATER_LEVEL),
                    dryingPerMinute = reader.float("DRYING_PER_MINUTE", DEFAULT_DRYING_PER_MINUTE),
                    statusInterval = reader.int(
                        "STATUS_INTERVAL_SECONDS",
                        DEFAULT_STATUS_INTERVAL_SECONDS,
                        1..Int.MAX_VALUE
                    ).seconds,
                    subscriberTtl = SUBSCRIBER_TTL,
                    fault = reader.fault("FAULT")
                )
            )
        }
    }
}

private class EnvReader(private val env: Map<String, String>) {

    fun required(key: String): String = requireNotNull(value(key)) { "$key must be set" }

    fun string(key: String, default: String): String = value(key) ?: default

    fun int(key: String, default: Int, range: IntRange): Int {
        val parsed = value(key)?.let { raw ->
            requireNotNull(raw.toIntOrNull()) { "$key must be a whole number, was '$raw'" }
        } ?: default
        require(parsed in range) { "$key must be within $range, was $parsed" }
        return parsed
    }

    fun float(key: String, default: Float): Float {
        val parsed = value(key)?.let { raw ->
            requireNotNull(raw.toFloatOrNull()) { "$key must be a number, was '$raw'" }
        } ?: default
        require(parsed >= 0f) { "$key must not be negative, was $parsed" }
        return parsed
    }

    fun level(key: String, default: Float): Float {
        val parsed = float(key, default)
        require(parsed in MIN_LEVEL..MAX_LEVEL) { "$key must be within $MIN_LEVEL..$MAX_LEVEL, was $parsed" }
        return parsed
    }

    fun fault(key: String): Fault = value(key)?.let { raw ->
        requireNotNull(Fault.fromKey(raw)) {
            "$key must be one of ${Fault.entries.joinToString { it.key }}, was '$raw'"
        }
    } ?: Fault.NONE

    private fun value(key: String): String? = env[key]?.trim()?.takeIf { it.isNotEmpty() }
}
