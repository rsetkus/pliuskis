package lt.setkus.pliuskis.mockdevice.plant

import kotlin.time.Duration
import kotlin.time.DurationUnit

/** Both values use the firmware's 0..10 scale (10 = wet / full); the app warns below 5. */
const val MIN_LEVEL = 0f
const val MAX_LEVEL = 10f

private const val WATER_DOSE = 3f
private const val WATER_PER_WATERING = 1f

/** Simulated soil humidity and water reservoir level. */
data class PlantState(
    val humidity: Float,
    val waterLevel: Float
) {
    val canWater: Boolean
        get() = waterLevel > MIN_LEVEL

    /** Soil dries out linearly over time. */
    fun dry(elapsed: Duration, dryingPerMinute: Float): PlantState =
        copy(humidity = clamp(humidity - dryingPerMinute * elapsed.toDouble(DurationUnit.MINUTES).toFloat()))

    /** One watering raises humidity and uses up some of the reservoir; an empty reservoir changes nothing. */
    fun water(): PlantState = if (canWater) {
        PlantState(
            humidity = clamp(humidity + WATER_DOSE),
            waterLevel = clamp(waterLevel - WATER_PER_WATERING)
        )
    } else {
        this
    }
}

private fun clamp(value: Float) = value.coerceIn(MIN_LEVEL, MAX_LEVEL)
