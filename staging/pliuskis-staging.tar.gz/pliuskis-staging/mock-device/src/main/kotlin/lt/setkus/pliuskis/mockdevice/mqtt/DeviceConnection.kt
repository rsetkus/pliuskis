package lt.setkus.pliuskis.mockdevice.mqtt

import kotlinx.coroutines.channels.ReceiveChannel

sealed interface ConnectionEvent {
    /** Sent after the first connect and after every automatic reconnect. */
    data object Connected : ConnectionEvent

    /** A message on one of the device's subscribed topics. */
    data class Message(val topic: String, val payload: String) : ConnectionEvent
}

/** The device's single MQTT connection. Its Last Will marks the device `offline`. */
interface DeviceConnection {

    val events: ReceiveChannel<ConnectionEvent>

    /** Starts connecting; keeps retrying until the broker accepts the connection. */
    fun connect()

    /** @return `false` if the broker did not confirm the subscription. */
    suspend fun subscribe(topic: String): Boolean

    /** Publishes at QoS 1. @return `false` if the broker did not confirm the message. */
    suspend fun publish(topic: String, payload: String, retain: Boolean): Boolean

    /**
     * Clean shutdown: publishes retained `offline`, then disconnects. A clean DISCONNECT suppresses the Last Will,
     * so the device has to announce `offline` itself, exactly like the firmware does on Ctrl-C.
     */
    suspend fun goOffline()
}
