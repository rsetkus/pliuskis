package lt.setkus.pliuskis.mockdevice.device

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import kotlinx.datetime.Clock
import kotlinx.datetime.Instant
import lt.setkus.pliuskis.mockdevice.Logger
import lt.setkus.pliuskis.mockdevice.config.Fault
import lt.setkus.pliuskis.mockdevice.config.MockDeviceConfig
import lt.setkus.pliuskis.mockdevice.contract.DeviceInfo
import lt.setkus.pliuskis.mockdevice.contract.ONLINE
import lt.setkus.pliuskis.mockdevice.contract.Payloads
import lt.setkus.pliuskis.mockdevice.contract.SystemStatePayload
import lt.setkus.pliuskis.mockdevice.contract.Topics
import lt.setkus.pliuskis.mockdevice.contract.WATER_COMMAND
import lt.setkus.pliuskis.mockdevice.mqtt.ConnectionEvent
import lt.setkus.pliuskis.mockdevice.mqtt.DeviceConnection
import lt.setkus.pliuskis.mockdevice.plant.PlantState
import kotlin.math.roundToInt
import kotlin.time.Duration

private const val PAYLOAD_PRECISION = 100f

/**
 * A simulated plant device speaking the app's MQTT contract.
 *
 * Broker events and simulation ticks are merged into one flow and handled one at a time, so the state below is
 * only ever touched by a single coroutine.
 */
class MockDevice(
    private val config: MockDeviceConfig,
    private val connection: DeviceConnection,
    private val clock: Clock,
    private val log: Logger
) {
    private val deviceId = config.device.id
    private val simulation = config.simulation
    private val infoPayload = Payloads.encode(DeviceInfo(config.device.name, deviceId, config.device.type))

    private var plant = PlantState(simulation.initialHumidity, simulation.initialWaterLevel)

    /** Apps that asked for status recently, by client id, with the time of their last request. */
    private var subscribers: Map<String, Instant> = emptyMap()
    private var subscribed = false

    /** Connects and runs the device until [scope] or the returned job is cancelled. */
    fun start(scope: CoroutineScope): Job = scope.launch {
        log.info("Starting '${config.device.name}' (fault: ${simulation.fault.key})")
        connection.connect()
        merge(connection.events.receiveAsFlow().map(Event::Broker), ticks(simulation.statusInterval))
            .collect(::handle)
    }

    private suspend fun handle(event: Event) = when (event) {
        Event.Tick -> onTick()
        is Event.Broker -> when (val brokerEvent = event.event) {
            ConnectionEvent.Connected -> onConnected()
            is ConnectionEvent.Message -> onMessage(brokerEvent)
        }
    }

    /** Same birth sequence as the firmware, repeated after every reconnect. */
    private suspend fun onConnected() {
        log.info("Connected; announcing on ${Topics.info(deviceId)}")
        connection.publish(Topics.info(deviceId), infoPayload, retain = true)
        connection.publish(Topics.availability(deviceId), ONLINE, retain = true)
        // The client restores its subscriptions after a reconnect by itself.
        if (!subscribed) {
            subscribed = connection.subscribe(Topics.statusRequest(deviceId)) &&
                connection.subscribe(Topics.command(deviceId))
        }
    }

    private suspend fun onMessage(message: ConnectionEvent.Message) = when (message.topic) {
        Topics.statusRequest(deviceId) -> onStatusRequest(message.payload)
        Topics.command(deviceId) -> onCommand(message.payload)
        else -> log.warn("Ignoring message on unexpected topic ${message.topic}")
    }

    private suspend fun onStatusRequest(payload: String) {
        val request = Payloads.decodeStatusRequest(payload)
        if (request == null) {
            log.warn("Ignoring malformed status request: $payload")
        } else {
            log.info("Status requested by ${request.applicationId}")
            subscribers = subscribers + (request.applicationId to clock.now())
            publishStatus(listOf(request.applicationId))
        }
    }

    private suspend fun onCommand(payload: String) {
        val command = Payloads.decodeCommand(payload)?.command
        when {
            command != WATER_COMMAND -> log.warn("Ignoring unknown command: $payload")
            !plant.canWater -> log.warn("Water reservoir is empty; nothing to water with")
            else -> {
                plant = plant.water()
                log.info("Watered: humidity ${plant.humidity}, water level ${plant.waterLevel}")
                publishStatus(subscribers.keys)
            }
        }
    }

    /**
     * Republishing on every tick also covers the app subscribing to its reply topic only after it sent the
     * request: a reply it missed is followed by another one within one interval.
     */
    private suspend fun onTick() {
        plant = plant.dry(simulation.statusInterval, simulation.dryingPerMinute)
        val now = clock.now()
        val expired = subscribers.filterValues { requestedAt -> now - requestedAt >= simulation.subscriberTtl }.keys
        expired.forEach { applicationId ->
            log.info("Stopping status updates to $applicationId: no request for ${simulation.subscriberTtl}")
        }
        subscribers = subscribers - expired
        publishStatus(subscribers.keys)
    }

    private suspend fun publishStatus(applicationIds: Collection<String>) {
        if (simulation.fault != Fault.SILENT && applicationIds.isNotEmpty()) {
            val payload = statusPayload()
            applicationIds.forEach { applicationId ->
                connection.publish(Topics.statusReply(applicationId, deviceId), payload, retain = false)
            }
        }
    }

    private fun statusPayload(): String {
        val state = SystemStatePayload(
            humidity = plant.humidity.rounded(),
            waterLevel = plant.waterLevel.rounded(),
            timestamp = clock.now()
        )
        return if (simulation.fault == Fault.MALFORMED_STATUS) {
            Payloads.encodeWithUnknownField(state)
        } else {
            Payloads.encode(state)
        }
    }
}

private sealed interface Event {
    data object Tick : Event
    data class Broker(val event: ConnectionEvent) : Event
}

private fun ticks(interval: Duration): Flow<Event> = flow {
    while (true) {
        delay(interval)
        emit(Event.Tick)
    }
}

private fun Float.rounded(): Float = (this * PAYLOAD_PRECISION).roundToInt() / PAYLOAD_PRECISION
