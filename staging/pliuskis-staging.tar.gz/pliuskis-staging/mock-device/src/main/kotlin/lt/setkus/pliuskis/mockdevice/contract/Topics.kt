package lt.setkus.pliuskis.mockdevice.contract

/** Availability payloads; the app treats only the exact string `online` as online. */
const val ONLINE = "online"
const val OFFLINE = "offline"

private val SAFE_ID = Regex("[A-Za-z0-9_-]+")

/**
 * Ids end up as MQTT topic segments and in the app's `control/{deviceId}` route, so `/`, `+`, `#`
 * and anything that would need URL encoding are rejected.
 */
fun isSafeId(value: String): Boolean = SAFE_ID.matches(value)

/** Topics shared with the app (`core/data`) and the Pico firmware. Change all sides together. */
object Topics {
    /** Retained JSON description, published by the device on every connect. */
    fun info(deviceId: String) = "devices/$deviceId/info"

    /** Retained `online`/`offline`; `offline` is also the device's Last Will. */
    fun availability(deviceId: String) = "devices/$deviceId/availability"

    /** The app asks for status here, sending its own client id as `applicationId`. */
    fun statusRequest(deviceId: String) = "devices/$deviceId/status"

    /** The app sends `{"command":"water"}` here. */
    fun command(deviceId: String) = "devices/$deviceId/command"

    /** Where the device answers a status request; the app subscribes with its own client id. */
    fun statusReply(applicationId: String, deviceId: String) = "application/$applicationId/$deviceId/status"
}
