package lt.setkus.pliuskis.mockdevice

import java.time.Instant

/** Timestamped, device-prefixed lines on stdout, so `docker compose logs` reads like a device console. */
class Logger(private val deviceId: String) {

    fun info(message: String) = write("INFO", message)

    fun warn(message: String) = write("WARN", message)

    fun error(message: String) = write("ERROR", message)

    private fun write(level: String, message: String) = println("${Instant.now()} $level [$deviceId] $message")
}
