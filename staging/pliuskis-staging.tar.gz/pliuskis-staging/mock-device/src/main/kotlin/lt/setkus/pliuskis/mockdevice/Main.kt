package lt.setkus.pliuskis.mockdevice

import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.runBlocking
import kotlinx.datetime.Clock
import lt.setkus.pliuskis.mockdevice.config.MockDeviceConfig
import lt.setkus.pliuskis.mockdevice.device.MockDevice
import lt.setkus.pliuskis.mockdevice.mqtt.DeviceConnection
import lt.setkus.pliuskis.mockdevice.mqtt.HiveMqttDeviceConnection
import java.util.concurrent.atomic.AtomicReference
import kotlin.system.exitProcess

private const val EXIT_CONFIG_ERROR = 2
private const val EXIT_DEVICE_FAILED = 1

fun main() {
    val config = runCatching { MockDeviceConfig.fromEnv(System.getenv()) }.getOrElse { error ->
        System.err.println("Invalid configuration: ${error.message}")
        exitProcess(EXIT_CONFIG_ERROR)
    }
    val log = Logger(config.device.id)
    val connection = HiveMqttDeviceConnection(config.broker, config.device.id, log)
    val failure = AtomicReference<Throwable>()
    val scope = CoroutineScope(
        SupervisorJob() + Dispatchers.Default + CoroutineExceptionHandler { _, error -> failure.set(error) }
    )
    val device = MockDevice(config, connection, Clock.System, log).start(scope)

    // SIGTERM (`docker compose stop`, Ctrl-C) is a clean shutdown; SIGKILL leaves it to the Last Will.
    Runtime.getRuntime().addShutdownHook(Thread { shutDown(device, connection, log) })

    runBlocking { device.join() }
    failure.get()?.let { error ->
        log.error("Device stopped unexpectedly: $error")
        exitProcess(EXIT_DEVICE_FAILED)
    }
}

/** Stops the device first, so a reconnect can't republish `online` after the device went offline. */
private fun shutDown(device: Job, connection: DeviceConnection, log: Logger) = runBlocking {
    log.info("Shutting down")
    device.cancelAndJoin()
    connection.goOffline()
}
