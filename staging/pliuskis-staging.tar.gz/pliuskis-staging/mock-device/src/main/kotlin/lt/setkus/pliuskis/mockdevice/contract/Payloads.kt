package lt.setkus.pliuskis.mockdevice.contract

import kotlinx.datetime.Instant
import kotlinx.datetime.serializers.InstantComponentSerializer
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonObject

const val WATER_COMMAND = "water"

/** Retained on `devices/{id}/info`. Mirrors the app's `DeviceDomainModel`. */
@Serializable
data class DeviceInfo(
    val name: String,
    val deviceId: String,
    val type: String
)

/** Sent by the app on `devices/{id}/status`. Mirrors the app's `SystemUpdateMessageModel`. */
@Serializable
data class StatusRequest(val applicationId: String)

/**
 * Sent to `application/{applicationId}/{id}/status`. Mirrors the app's `SystemState`, which is decoded
 * with a strict `Json`: no extra keys, and the timestamp is an object, not a number or an ISO string.
 */
@Serializable
data class SystemStatePayload(
    val humidity: Float,
    val waterLevel: Float,
    @Serializable(with = InstantComponentSerializer::class)
    val timestamp: Instant
)

/** Sent by the app on `devices/{id}/command`. */
@Serializable
data class CommandMessage(val command: String)

/** Field a newer firmware might add; the app's strict decoder rejects any unknown key. */
private const val UNKNOWN_FIELD = "battery"
private const val UNKNOWN_FIELD_VALUE = 80

object Payloads {

    private val lenient = Json { ignoreUnknownKeys = true }

    fun encode(info: DeviceInfo): String = Json.encodeToString(DeviceInfo.serializer(), info)

    fun encode(state: SystemStatePayload): String = Json.encodeToString(SystemStatePayload.serializer(), state)

    /** A valid status plus one unknown key: the app's status flow fails on it and shows its Error screen. */
    fun encodeWithUnknownField(state: SystemStatePayload): String {
        val valid = Json.encodeToJsonElement(SystemStatePayload.serializer(), state).jsonObject
        return JsonObject(valid + (UNKNOWN_FIELD to JsonPrimitive(UNKNOWN_FIELD_VALUE))).toString()
    }

    /** `null` when the payload is malformed or its `applicationId` can't be used as a topic segment. */
    fun decodeStatusRequest(payload: String): StatusRequest? =
        runCatching { lenient.decodeFromString(StatusRequest.serializer(), payload) }
            .getOrNull()
            ?.takeIf { isSafeId(it.applicationId) }

    /** `null` when the payload is malformed. */
    fun decodeCommand(payload: String): CommandMessage? =
        runCatching { lenient.decodeFromString(CommandMessage.serializer(), payload) }.getOrNull()
}
