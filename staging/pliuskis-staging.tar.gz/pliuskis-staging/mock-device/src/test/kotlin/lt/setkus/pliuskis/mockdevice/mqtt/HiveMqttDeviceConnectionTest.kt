package lt.setkus.pliuskis.mockdevice.mqtt

import com.hivemq.client.mqtt.MqttClient
import com.hivemq.client.mqtt.MqttGlobalPublishFilter
import com.hivemq.client.mqtt.datatypes.MqttQos
import com.hivemq.client.mqtt.mqtt3.Mqtt3BlockingClient
import com.hivemq.client.mqtt.mqtt3.message.publish.Mqtt3Publish
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.floats.plusOrMinus
import io.kotest.matchers.nulls.shouldNotBeNull
import io.kotest.matchers.shouldBe
import io.moquette.broker.Server
import io.moquette.broker.config.MemoryConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.datetime.Clock
import kotlinx.serialization.json.Json
import lt.setkus.pliuskis.mockdevice.Logger
import lt.setkus.pliuskis.mockdevice.config.MockDeviceConfig
import lt.setkus.pliuskis.mockdevice.contract.SystemStatePayload
import lt.setkus.pliuskis.mockdevice.device.MockDevice
import java.net.ServerSocket
import java.util.Properties
import java.util.concurrent.TimeUnit

private const val HOST = "127.0.0.1"
private const val APP = "android-debug-client"
private const val RECEIVE_TIMEOUT_SECONDS = 5L
private const val REQUEST_ATTEMPTS = 5

private fun Mqtt3BlockingClient.Mqtt3Publishes.next(): Mqtt3Publish? =
    receive(RECEIVE_TIMEOUT_SECONDS, TimeUnit.SECONDS).orElse(null)

private fun Mqtt3Publish.text() = String(payloadAsBytes, Charsets.UTF_8)

private fun Mqtt3BlockingClient.subscribeTo(topic: String) {
    subscribeWith().topicFilter(topic).qos(MqttQos.AT_LEAST_ONCE).send()
}

/** The real HiveMQ connection and device against an embedded broker, observed by a client acting as the app. */
class HiveMqttDeviceConnectionTest : FunSpec({

    val port = ServerSocket(0).use { it.localPort }
    val broker = Server()
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    beforeSpec {
        val properties = Properties().apply {
            setProperty("host", HOST)
            setProperty("port", port.toString())
            setProperty("persistence_enabled", "false")
            setProperty("telemetry_enabled", "false")
            setProperty("allow_anonymous", "true")
        }
        broker.startServer(MemoryConfig(properties))

        val config = MockDeviceConfig.fromEnv(
            mapOf("MQTT_HOST" to HOST, "MQTT_PORT" to port.toString(), "DEVICE_ID" to "basil", "DEVICE_NAME" to "Basil")
        )
        val log = Logger("basil")
        MockDevice(config, HiveMqttDeviceConnection(config.broker, "basil", log), Clock.System, log).start(scope)
    }

    afterSpec {
        scope.cancel()
        broker.stopServer()
    }

    fun withApp(block: (Mqtt3BlockingClient, Mqtt3BlockingClient.Mqtt3Publishes) -> Unit) {
        val app = MqttClient.builder()
            .useMqttVersion3()
            .identifier(APP)
            .serverHost(HOST)
            .serverPort(port)
            .buildBlocking()
        app.connect()
        try {
            app.publishes(MqttGlobalPublishFilter.ALL).use { publishes -> block(app, publishes) }
        } finally {
            app.disconnect()
        }
    }

    test("a subscriber that connects after the device still discovers it from retained messages") {
        // Wait until the device has announced itself; info is published before availability.
        withApp { app, publishes ->
            app.subscribeTo("devices/basil/availability")
            publishes.next()?.text() shouldBe "online"
        }

        withApp { app, publishes ->
            app.subscribeTo("devices/+/info")
            val info = publishes.next().shouldNotBeNull()

            // The device announced itself only once, before this subscription, so this came from the retained store.
            // (Moquette doesn't set the RETAIN flag on that delivery; Mosquitto does.)
            info.topic.toString() shouldBe "devices/basil/info"
            info.text() shouldBe """{"name":"Basil","deviceId":"basil","type":"plant"}"""
        }
    }

    test("answers the app's status request on the app's reply topic") {
        withApp { app, publishes ->
            app.subscribeTo("application/$APP/basil/status")

            // The device may still be subscribing to its request topic, so ask until it answers.
            val reply = (1..REQUEST_ATTEMPTS).asSequence()
                .map {
                    app.publishWith()
                        .topic("devices/basil/status")
                        .payload("""{"applicationId":"$APP"}""".toByteArray())
                        .qos(MqttQos.AT_LEAST_ONCE)
                        .send()
                    publishes.next()
                }
                .firstOrNull { it != null }

            val state = Json.decodeFromString(SystemStatePayload.serializer(), reply.shouldNotBeNull().text())
            // The plant has been drying since the device started.
            state.humidity shouldBe (8f plusOrMinus 0.5f)
            state.waterLevel shouldBe 10f
        }
    }
})
