package lt.setkus.pliuskis.mockdevice.device

import io.kotest.assertions.throwables.shouldThrowAny
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.collections.shouldBeEmpty
import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.collections.shouldHaveSize
import io.kotest.matchers.floats.shouldBeLessThan
import io.kotest.matchers.shouldBe
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.datetime.Clock
import kotlinx.datetime.Instant
import kotlinx.serialization.json.Json
import lt.setkus.pliuskis.mockdevice.Logger
import lt.setkus.pliuskis.mockdevice.config.BrokerConfig
import lt.setkus.pliuskis.mockdevice.config.DeviceConfig
import lt.setkus.pliuskis.mockdevice.config.Fault
import lt.setkus.pliuskis.mockdevice.config.MockDeviceConfig
import lt.setkus.pliuskis.mockdevice.config.SimulationConfig
import lt.setkus.pliuskis.mockdevice.contract.SystemStatePayload
import lt.setkus.pliuskis.mockdevice.mqtt.ConnectionEvent
import kotlin.time.Duration.Companion.minutes
import kotlin.time.Duration.Companion.seconds

private const val APP = "android-debug-client"
private const val STATUS_REQUEST_TOPIC = "devices/basil/status"
private const val COMMAND_TOPIC = "devices/basil/command"
private const val REPLY_TOPIC = "application/$APP/basil/status"
private val INTERVAL = 5.seconds
private val TTL = 10.minutes

private fun config(fault: Fault, humidity: Float, waterLevel: Float) = MockDeviceConfig(
    broker = BrokerConfig(host = "localhost", port = 1883, keepAliveSeconds = 60),
    device = DeviceConfig(id = "basil", name = "Basil", type = "plant"),
    simulation = SimulationConfig(
        initialHumidity = humidity,
        initialWaterLevel = waterLevel,
        dryingPerMinute = 0.6f,
        statusInterval = INTERVAL,
        subscriberTtl = TTL,
        fault = fault
    )
)

/** Starts a device on virtual time; its clock follows the test scheduler. */
@OptIn(ExperimentalCoroutinesApi::class)
private fun TestScope.startDevice(
    fault: Fault = Fault.NONE,
    humidity: Float = 8f,
    waterLevel: Float = 2f
): FakeDeviceConnection {
    val connection = FakeDeviceConnection()
    val clock = object : Clock {
        override fun now() = Instant.fromEpochMilliseconds(testScheduler.currentTime)
    }
    MockDevice(config(fault, humidity, waterLevel), connection, clock, Logger("basil")).start(backgroundScope)
    connection.send(ConnectionEvent.Connected)
    runCurrent()
    return connection
}

private fun FakeDeviceConnection.requestStatus(applicationId: String = APP) =
    send(ConnectionEvent.Message(STATUS_REQUEST_TOPIC, """{"applicationId":"$applicationId"}"""))

private fun FakeDeviceConnection.repliesTo(applicationId: String = APP) =
    published.filter { it.topic == "application/$applicationId/basil/status" }

private fun Published.state() = Json.decodeFromString(SystemStatePayload.serializer(), payload)

@OptIn(ExperimentalCoroutinesApi::class)
class MockDeviceTest : FunSpec({

    test("announces retained info, then online, then listens for requests and commands") {
        runTest {
            val connection = startDevice()

            connection.connectCalls shouldBe 1
            connection.published shouldContainExactly listOf(
                Published("devices/basil/info", """{"name":"Basil","deviceId":"basil","type":"plant"}""", true),
                Published("devices/basil/availability", "online", true)
            )
            connection.subscriptions shouldContainExactly listOf(STATUS_REQUEST_TOPIC, COMMAND_TOPIC)
        }
    }

    test("re-announces after a reconnect without subscribing again") {
        runTest {
            val connection = startDevice()

            connection.send(ConnectionEvent.Connected)
            runCurrent()

            connection.published.map { it.topic } shouldContainExactly listOf(
                "devices/basil/info",
                "devices/basil/availability",
                "devices/basil/info",
                "devices/basil/availability"
            )
            connection.subscriptions shouldHaveSize 2
        }
    }

    test("answers a status request right away on the app's reply topic") {
        runTest {
            val connection = startDevice(humidity = 8f, waterLevel = 2f)

            connection.requestStatus()
            runCurrent()

            val reply = connection.repliesTo().single()
            reply.topic shouldBe REPLY_TOPIC
            reply.retain shouldBe false
            reply.state() shouldBe SystemStatePayload(8f, 2f, Instant.fromEpochMilliseconds(0))
        }
    }

    test("keeps publishing every interval, with the plant drying, until the app stops asking") {
        runTest {
            val connection = startDevice(humidity = 8f)
            connection.requestStatus()
            runCurrent()

            advanceTimeBy(INTERVAL)
            runCurrent()

            val replies = connection.repliesTo()
            replies shouldHaveSize 2
            replies.last().state().humidity shouldBeLessThan 8f
            replies.last().state().timestamp shouldBe Instant.fromEpochMilliseconds(INTERVAL.inWholeMilliseconds)

            advanceTimeBy(TTL + 1.minutes)
            runCurrent()

            // The immediate reply plus one per tick while the request is younger than the TTL.
            connection.repliesTo() shouldHaveSize 1 + (TTL / INTERVAL).toInt() - 1
        }
    }

    test("a repeated request keeps the updates going") {
        runTest {
            val connection = startDevice()
            connection.requestStatus()
            advanceTimeBy(TTL - INTERVAL)
            runCurrent()

            connection.requestStatus()
            runCurrent()
            val before = connection.repliesTo().size
            // The first request alone expires on this tick.
            advanceTimeBy(INTERVAL)
            runCurrent()

            connection.repliesTo() shouldHaveSize before + 1
        }
    }

    test("publishes to every app that asked") {
        runTest {
            val connection = startDevice()
            connection.requestStatus("phone-1")
            connection.requestStatus("phone-2")
            runCurrent()

            advanceTimeBy(INTERVAL)
            runCurrent()

            connection.repliesTo("phone-1") shouldHaveSize 2
            connection.repliesTo("phone-2") shouldHaveSize 2
        }
    }

    test("watering raises humidity, uses water and pushes the new state") {
        runTest {
            val connection = startDevice(humidity = 4f, waterLevel = 2f)
            connection.requestStatus()
            runCurrent()

            connection.send(ConnectionEvent.Message(COMMAND_TOPIC, """{"command":"water"}"""))
            runCurrent()

            val replies = connection.repliesTo()
            replies shouldHaveSize 2
            replies.last().state() shouldBe SystemStatePayload(7f, 1f, Instant.fromEpochMilliseconds(0))
        }
    }

    test("an empty reservoir can't water the plant") {
        runTest {
            val connection = startDevice(humidity = 4f, waterLevel = 0f)
            connection.requestStatus()
            runCurrent()

            connection.send(ConnectionEvent.Message(COMMAND_TOPIC, """{"command":"water"}"""))
            runCurrent()

            connection.repliesTo() shouldHaveSize 1
        }
    }

    test("ignores malformed requests, unknown commands and stray topics") {
        runTest {
            val connection = startDevice()
            val announcements = connection.published.toList()

            connection.send(ConnectionEvent.Message(STATUS_REQUEST_TOPIC, "not json"))
            connection.send(ConnectionEvent.Message(STATUS_REQUEST_TOPIC, """{"applicationId":"a/b"}"""))
            connection.send(ConnectionEvent.Message(COMMAND_TOPIC, """{"command":"dance"}"""))
            connection.send(ConnectionEvent.Message("devices/fern/status", """{"applicationId":"$APP"}"""))
            advanceTimeBy(INTERVAL)
            runCurrent()

            connection.published shouldContainExactly announcements
        }
    }

    test("a silent device announces itself but never answers") {
        runTest {
            val connection = startDevice(fault = Fault.SILENT)

            connection.requestStatus()
            advanceTimeBy(INTERVAL * 3)
            runCurrent()

            connection.published.map { it.topic } shouldContainExactly listOf(
                "devices/basil/info",
                "devices/basil/availability"
            )
            connection.repliesTo().shouldBeEmpty()
        }
    }

    test("a malformed-status device answers with something the app can't decode") {
        runTest {
            val connection = startDevice(fault = Fault.MALFORMED_STATUS)

            connection.requestStatus()
            runCurrent()

            shouldThrowAny { connection.repliesTo().single().state() }
        }
    }
})
