package lt.setkus.pliuskis.mockdevice.device

import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel
import lt.setkus.pliuskis.mockdevice.mqtt.ConnectionEvent
import lt.setkus.pliuskis.mockdevice.mqtt.DeviceConnection

data class Published(val topic: String, val payload: String, val retain: Boolean)

/** Records what the device does; [send] plays the broker. */
class FakeDeviceConnection : DeviceConnection {

    private val channel = Channel<ConnectionEvent>(Channel.UNLIMITED)
    override val events: ReceiveChannel<ConnectionEvent> = channel

    val published = mutableListOf<Published>()
    val subscriptions = mutableListOf<String>()
    var connectCalls = 0
        private set

    fun send(event: ConnectionEvent) {
        channel.trySend(event)
    }

    override fun connect() {
        connectCalls++
    }

    override suspend fun subscribe(topic: String): Boolean {
        subscriptions += topic
        return true
    }

    override suspend fun publish(topic: String, payload: String, retain: Boolean): Boolean {
        published += Published(topic, payload, retain)
        return true
    }

    override suspend fun goOffline() = Unit
}
