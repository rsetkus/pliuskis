package lt.setkus.pliuskis.mockdevice.plant

import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.floats.plusOrMinus
import io.kotest.matchers.shouldBe
import kotlin.time.Duration.Companion.minutes
import kotlin.time.Duration.Companion.seconds

class PlantStateTest : FunSpec({

    test("soil dries linearly and the reservoir is untouched") {
        val dried = PlantState(humidity = 8f, waterLevel = 5f).dry(2.minutes, dryingPerMinute = 0.5f)

        dried.humidity shouldBe (7f plusOrMinus 0.0001f)
        dried.waterLevel shouldBe 5f
    }

    test("drying works on sub-minute ticks") {
        PlantState(8f, 5f).dry(30.seconds, dryingPerMinute = 0.6f).humidity shouldBe (7.7f plusOrMinus 0.0001f)
    }

    test("humidity never drops below zero") {
        PlantState(humidity = 0.2f, waterLevel = 5f).dry(10.minutes, dryingPerMinute = 0.5f).humidity shouldBe 0f
    }

    test("watering raises humidity and uses water") {
        PlantState(humidity = 4f, waterLevel = 5f).water() shouldBe PlantState(humidity = 7f, waterLevel = 4f)
    }

    test("humidity is capped at the top of the scale") {
        PlantState(humidity = 9f, waterLevel = 5f).water() shouldBe PlantState(humidity = 10f, waterLevel = 4f)
    }

    test("the last bit of water still waters the plant") {
        PlantState(humidity = 4f, waterLevel = 0.5f).water() shouldBe PlantState(humidity = 7f, waterLevel = 0f)
    }

    test("an empty reservoir can't water") {
        val empty = PlantState(humidity = 4f, waterLevel = 0f)

        empty.canWater shouldBe false
        empty.water() shouldBe empty
    }
})
