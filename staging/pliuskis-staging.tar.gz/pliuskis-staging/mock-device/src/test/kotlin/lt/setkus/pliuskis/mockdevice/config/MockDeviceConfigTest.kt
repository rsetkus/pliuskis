package lt.setkus.pliuskis.mockdevice.config

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.core.spec.style.FunSpec
import io.kotest.datatest.withData
import io.kotest.matchers.shouldBe
import io.kotest.matchers.string.shouldContain
import kotlin.time.Duration.Companion.minutes
import kotlin.time.Duration.Companion.seconds

class MockDeviceConfigTest : FunSpec({

    test("only DEVICE_ID is required; everything else has firmware-like defaults") {
        val config = MockDeviceConfig.fromEnv(mapOf("DEVICE_ID" to "basil"))

        config shouldBe MockDeviceConfig(
            broker = BrokerConfig(host = "localhost", port = 1883, keepAliveSeconds = 60),
            device = DeviceConfig(id = "basil", name = "basil", type = "plant"),
            simulation = SimulationConfig(
                initialHumidity = 8f,
                initialWaterLevel = 10f,
                dryingPerMinute = 0.5f,
                statusInterval = 5.seconds,
                subscriberTtl = 10.minutes,
                fault = Fault.NONE
            )
        )
    }

    test("reads every variable") {
        val config = MockDeviceConfig.fromEnv(
            mapOf(
                "MQTT_HOST" to "broker",
                "MQTT_PORT" to "1884",
                "MQTT_KEEPALIVE_SECONDS" to "4",
                "DEVICE_ID" to "fern_2",
                "DEVICE_NAME" to " Fern ",
                "DEVICE_TYPE" to "cactus",
                "HUMIDITY" to "3",
                "WATER_LEVEL" to "2.5",
                "DRYING_PER_MINUTE" to "0",
                "STATUS_INTERVAL_SECONDS" to "1",
                "FAULT" to "malformed-status"
            )
        )

        config.broker shouldBe BrokerConfig(host = "broker", port = 1884, keepAliveSeconds = 4)
        config.device shouldBe DeviceConfig(id = "fern_2", name = "Fern", type = "cactus")
        config.simulation shouldBe SimulationConfig(
            initialHumidity = 3f,
            initialWaterLevel = 2.5f,
            dryingPerMinute = 0f,
            statusInterval = 1.seconds,
            subscriberTtl = 10.minutes,
            fault = Fault.MALFORMED_STATUS
        )
    }

    context("DEVICE_ID must be present") {
        withData(emptyMap(), mapOf("DEVICE_ID" to "  ")) { env ->
            shouldThrow<IllegalArgumentException> { MockDeviceConfig.fromEnv(env) }
                .message shouldBe "DEVICE_ID must be set"
        }
    }

    context("DEVICE_ID must be usable as a topic segment and route argument") {
        withData("a/b", "plant+1", "#", "basil plant", "żolė") { id ->
            shouldThrow<IllegalArgumentException> { MockDeviceConfig.fromEnv(mapOf("DEVICE_ID" to id)) }
                .message shouldContain "may only contain letters, digits"
        }
    }

    context("invalid values fail fast with the offending variable named") {
        withData(
            mapOf("MQTT_PORT" to "abc") to "MQTT_PORT must be a whole number, was 'abc'",
            mapOf("MQTT_PORT" to "0") to "MQTT_PORT must be within 1..65535, was 0",
            mapOf("MQTT_KEEPALIVE_SECONDS" to "0") to "MQTT_KEEPALIVE_SECONDS must be within 1..65535, was 0",
            mapOf("HUMIDITY" to "11") to "HUMIDITY must be within 0.0..10.0, was 11.0",
            mapOf("WATER_LEVEL" to "wet") to "WATER_LEVEL must be a number, was 'wet'",
            mapOf("DRYING_PER_MINUTE" to "-1") to "DRYING_PER_MINUTE must not be negative, was -1.0",
            mapOf("STATUS_INTERVAL_SECONDS" to "0") to "STATUS_INTERVAL_SECONDS must be within 1..2147483647, was 0",
            mapOf("FAULT" to "flaky") to "FAULT must be one of none, silent, malformed-status, was 'flaky'"
        ) { (overrides, message) ->
            shouldThrow<IllegalArgumentException> {
                MockDeviceConfig.fromEnv(mapOf("DEVICE_ID" to "basil") + overrides)
            }.message shouldBe message
        }
    }

    context("every fault has a key") {
        withData(Fault.entries) { fault ->
            val config = MockDeviceConfig.fromEnv(mapOf("DEVICE_ID" to "basil", "FAULT" to fault.key))

            config.simulation.fault shouldBe fault
        }
    }
})
