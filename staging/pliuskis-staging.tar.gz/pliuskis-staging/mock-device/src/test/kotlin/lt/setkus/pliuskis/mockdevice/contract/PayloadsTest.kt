package lt.setkus.pliuskis.mockdevice.contract

import io.kotest.assertions.throwables.shouldThrowAny
import io.kotest.core.spec.style.FunSpec
import io.kotest.datatest.withData
import io.kotest.matchers.nulls.shouldBeNull
import io.kotest.matchers.shouldBe
import kotlinx.datetime.Instant
import kotlinx.datetime.serializers.InstantComponentSerializer
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/** Copy of the app's `SystemState` (core/domain), decoded the way the app does it: plain, strict `Json`. */
@Serializable
private data class AppSystemState(
    val humidity: Float,
    val waterLevel: Float,
    @Serializable(with = InstantComponentSerializer::class)
    val timestamp: Instant
)

private fun decodeLikeTheApp(payload: String) = Json.decodeFromString(AppSystemState.serializer(), payload)

class PayloadsTest : FunSpec({

    test("info has exactly the fields the app's discovery decodes") {
        Payloads.encode(DeviceInfo(name = "Basil", deviceId = "basil", type = "plant")) shouldBe
            """{"name":"Basil","deviceId":"basil","type":"plant"}"""
    }

    test("status timestamp is an object and omits zero nanoseconds") {
        val state = SystemStatePayload(8f, 9.5f, Instant.fromEpochSeconds(1_760_000_000))

        Payloads.encode(state) shouldBe
            """{"humidity":8.0,"waterLevel":9.5,"timestamp":{"epochSeconds":1760000000}}"""
    }

    test("status timestamp carries non-zero nanoseconds") {
        val state = SystemStatePayload(8f, 9.5f, Instant.fromEpochSeconds(1_760_000_000, 250_000_000))

        Payloads.encode(state) shouldBe """{"humidity":8.0,"waterLevel":9.5,""" +
            """"timestamp":{"epochSeconds":1760000000,"nanosecondsOfSecond":250000000}}"""
    }

    test("the app's strict decoder accepts a status") {
        val timestamp = Instant.fromEpochSeconds(1_760_000_000, 250_000_000)

        decodeLikeTheApp(Payloads.encode(SystemStatePayload(3.25f, 2f, timestamp))) shouldBe
            AppSystemState(3.25f, 2f, timestamp)
    }

    test("a status with an unknown field breaks the app's strict decoder") {
        val payload = Payloads.encodeWithUnknownField(SystemStatePayload(3f, 2f, Instant.fromEpochSeconds(1)))

        payload shouldBe """{"humidity":3.0,"waterLevel":2.0,"timestamp":{"epochSeconds":1},"battery":80}"""
        shouldThrowAny { decodeLikeTheApp(payload) }
    }

    test("decodes the app's status request, tolerating extra fields") {
        Payloads.decodeStatusRequest("""{"applicationId":"android-debug-client"}""") shouldBe
            StatusRequest("android-debug-client")
        Payloads.decodeStatusRequest("""{"applicationId":"app-1","extra":true}""") shouldBe StatusRequest("app-1")
    }

    context("rejects status requests that are malformed or can't name a reply topic") {
        withData(
            nameFn = { "'$it'" },
            "",
            "not json",
            "{}",
            """{"applicationId":42}""",
            """{"applicationId":""}""",
            """{"applicationId":"a/b"}""",
            """{"applicationId":"#"}""",
            """{"applicationId":"+"}"""
        ) { payload ->
            Payloads.decodeStatusRequest(payload).shouldBeNull()
        }
    }

    test("decodes the app's water command") {
        Payloads.decodeCommand("""{"command":"water"}""") shouldBe CommandMessage(WATER_COMMAND)
    }

    context("rejects malformed commands") {
        withData(nameFn = { "'$it'" }, "", "water", "{}", """{"command":null}""") { payload ->
            Payloads.decodeCommand(payload).shouldBeNull()
        }
    }
})
